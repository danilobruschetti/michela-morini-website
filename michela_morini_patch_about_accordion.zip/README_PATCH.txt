Patch Chi sono accordion / formazione compatta

Sostituisci solo:
- index.html
- assets/css/style.css

Non sostituire main.js.

Modifiche:
- sezione Chi sono resa più leggibile con 3 mini-card a vista;
- storia completa in accordion <details>;
- formazione/certificazioni in accordion separato;
- quote finale sempre visibile;
- layout responsive coerente con lo stile del sito.
